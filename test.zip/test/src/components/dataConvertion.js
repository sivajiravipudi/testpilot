const dataConvertion = async(query) => {
    console.log(query)

    const url = 'http://localhost:5000/gettable?convert=' + query.replace('\'/g', '');
    console.log(url)
    let response = await fetch(url);
    console.log(Promise.resolve(response));
    return Promise.resolve(response.json());
    //console.log(response.json());
    //return OpenaiService.getChatCompletion('Vendor A costs 24500SGD');
    //return response.json();
};

export default dataConvertion;