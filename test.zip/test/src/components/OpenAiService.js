const OpenAI = require("openai");


const OpenaiService = {
    getChatCompletion: async function(query) {
        const completion = await openai.complete({
            model: "gpt-4",
            prompt: query,
            temperature: 0
        });
        return response.data.choices[0].text;
    }
};


module.exports.OpenaiService = OpenaiService;