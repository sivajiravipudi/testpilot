import React from 'react';
import './DataContainer.css';

const DataContainer = ({ data, title, children }) => {


    return ( <
            >
            <
            div className = 'data-container' >
            <
            div className = 'title-container' >
            <
            h2 className = 'title' > { title } < /h2> {
            title ? < hr / > : < > < />
        } <
        /div> <
    div className = 'content-container' > { children } <
        /div> < /
    div > <
        />
)
}


export default DataContainer;