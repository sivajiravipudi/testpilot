import React, { useState } from 'react';
import FileInput from './FileInput';
import readExcel from './readExcel';
import axios from 'axios';
import chatQuery from './chatQuery';
import Chatbot from './Chatbot';

const ExcelDisplay = () => {
    const [exceldata, setExcelData] = useState([]);
    const [sharedBreadcrumbs, setSharedBreadcrumbs] = useState([]);


    const handleFileSelect = async(file) => {
        try {
            const data = await readExcel(file);
            const formData = new FormData();
            formData.append('excelFile', file);
            axios.post('http://localhost:5000/upload', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            }).then(response => chatQuery('List top 5 questions that i can ask you?').then(result => {
                //console.log(result);
                //const sharedBreadcrumbs = [];
                const regex = /(?<=\d)\./;
                const res = result.output;
                const sharedBreadcrumbs = res.split(regex);
                //breadcrumbs.push(res.split(regex));
                setSharedBreadcrumbs(sharedBreadcrumbs);
                //console.log(sharedData);
                //console.log('breadcrumbs', breadcrumbs);
                //setExcelData(data);
            }));
        } catch (error) {
            console.error('error', error);
        }
    };
    return ( <
        div > < h1 > NextGen CoPilot < /h1><FileInput onFileSelect={handleFileSelect} / >
        <
        div > < BreadcrumbsContainer sharedBreadcrumbs = { sharedBreadcrumbs }
        /> < /div > <
        div className = 'table-container' >
        <
        table className = 'fixed-table' > < tbody > {
            exceldata.map((row, rowIndex) => ( <
                tr key = { rowIndex } > {
                    row.map((cell, cellIndex) => ( <
                        td key = { cellIndex } > { cell } < /td>
                    ))
                } <
                /tr>
            ))
        } <
        /tbody > < /table > < /div> < /
        div >
    );
};
export default ExcelDisplay;