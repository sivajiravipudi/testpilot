import React, { useState } from 'react';



const Search = ({ onQuerySubmit, placeholder }) => {
    const [query, setQuery] = useState('');


    const handleSearchClick = () => {
        // Call the onQuerySubmit function with the current query
        onQuerySubmit(query);

    };




    return ( <
        div style = { searchContainerStyle } >
        <
        input type = "text"
        placeholder = { placeholder }
        value = { query }
        onChange = {
            (event) => setQuery(event.target.value) }
        style = { searchInputStyle }
        /> <
        button style = { searchButtonStyle }
        onClick = { handleSearchClick } >
        <
        i className = "fas fa-search" > < /i> {/ * Font Awesome search icon * /} <
        /button> <
        /div>
    );
};

const searchContainerStyle = {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'flex-start',
    height: '100px',
};

const searchInputStyle = {
    padding: '10px',
    width: '500px',
    borderRadius: '5px',
    border: '1px solid #ccc',
    outline: 'none',
};
const searchButtonStyle = {
    padding: '10px',
    marginLeft: '10px', // Add some space between the input and the button
    backgroundColor: '#E91B13', // You can use any color you prefer
    color: '#fff',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
    outline: 'none',
};

export default Search;