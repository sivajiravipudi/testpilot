const chatQuery = async(query) => {
    console.log(query)    
    const url = 'http://localhost:5000/query?question=' + query;
    console.log(url)
    let response = await fetch(url);
    //console.log(response);
    return Promise.resolve(response.json());
    //console.log(response.json());
    //return OpenaiService.getChatCompletion('Vendor A costs 24500SGD');
    //return response.json();
};

export default chatQuery;