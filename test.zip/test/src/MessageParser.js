// MessageParser.js
class MessageParser {
    constructor(actionProvider) {
        this.actionProvider = actionProvider;
    }

    parse(message) {
        const lowerCaseMessage = message.toLowerCase();
        console.log(message);
        if (message != null) {
            this.actionProvider.callAPI(message);
        }
    }
}

export default MessageParser;