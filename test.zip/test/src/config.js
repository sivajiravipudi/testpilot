// config.js
const config = {
    botName: "My Chatbot",
    initialMessages: [{
        type: 'bot',
        id: '1',
        message: 'Hello! How can I assist you today?'
    }]
};
export default config;