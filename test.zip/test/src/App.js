import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import './App.css';

// Pages
import Client from './pages/Client';


const App = () => {
    return ( <
        >
        <
        div class = "container" >
        <
        Router >
        <
        Routes >
        <
        Route path = "/"
        element = { < Client / > }
        /> < /
        Routes > <
        /Router>  <
        /div> <
        / >
    );
};

export default App;