/*jshint esversion: 6 */

import React, { useState, useEffect } from 'react';
import Search from '../components/Search';
import { Container, Row, Col, Table } from 'react-bootstrap';
import DataContainer from '../components/DataContainer';
import './Client.css';
import FileInput from '../components/FileInput';
import { BeatLoader } from 'react-spinners';
import Chatbot from '../components/Chatbot';
import axios from 'axios';
import readExcel from '../components/readExcel';

import ExcelDisplay from '../components/ExcelDisplay';
import BreadcrumbsContainer from '../components/BreadcrumbsContainer';
import chatQuery from '../components/chatQuery';

const Client = () => {
    //const [file, setFile] = useState(null);
    const [responseData, setResponseData] = useState(null);
    const [loading, setLoading] = useState(false);
    const [sharedBreadcrumbs, setSharedBreadcrumbs] = useState([]);
    const [showBreadCrumbsComponent, setShowBreadCrumbsComponent] = useState(false);

    /*const handleFileUpload = (event) => {
        const uploadedFile = event.target.files[0];
        setFile(uploadedFile);
    }*/


    useEffect(() => {
        const showBreadCrumbs = () => {
            setShowBreadCrumbsComponent(true);
        };


        if (sharedBreadcrumbs.length > 0) {
            showBreadCrumbs();
        }

    }, [sharedBreadcrumbs]);


    const handleFileSelect = async(file) => {
        try {
            //const data = await readExcel(file);
            const formData = new FormData();
            formData.append('excelFile', file);
            axios.post('http://localhost:5000/upload', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            }).then(response => 
                chatQuery('list top 5 questions that can be asked from this data').then(result => {
                //console.log(result);
                //const sharedBreadcrumbs = [];

                const regex = /(?<=\d)\./;
                const delim = /[?\n0-9.]+/g;
                const res = result.output;
                //const formattedRes = res.replace('?\n', '');
                //console.log(formattedRes);
                const sharedBreadcrumbs = res.split(delim);
                console.log(sharedBreadcrumbs);
                setSharedBreadcrumbs(sharedBreadcrumbs);
                //console.log(sharedData);
                //console.log('breadcrumbs', breadcrumbs);
                //setExcelData(data);
            }));
        } catch (error) {
            console.error('error', error);
        }
    };

    
    return ( <
        >

        <
        div class = "section web-content" > < /div > <
        Row >
        <
        h1 className = 'header' > NextGen CPOPilot < /h1> <
        div class = 'header' > <
        FileInput onFileSelect = {(file) => handleFileSelect(file) }
        / > </div > <
        Col md = { 2 } >
        <
        Row >
        <
        Col md = { 2 } >
        <
        DataContainer title = "Virtual Assistant" >
        <
        Chatbot location = "cpo"
        tickerValue = ""
        queries = {
            sharedBreadcrumbs
        }
        / > <
        div >
        <
        /div > < /
        DataContainer > < /
        Col > <
        /Row> < /
        Col > <
        /Row>

        <
        />
    );
};

export default Client;

const containerStyle = {
    border: '1px solid black',
    padding: '20px',
    margin: '20px',

};